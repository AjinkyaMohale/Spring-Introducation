package com.javaconfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {
  public static void main(String[] args)
  {
	  ApplicationContext context=new AnnotationConfigApplicationContext(ProductConfig.class);
	  Product p1=(Product) context.getBean("product1");
	  p1.setProductId(101);
	  p1.setProductName("Tata Moters");
	  p1.setProductPrice(2000);
	  
	  System.out.println(p1.toString());
	  
  }
  
}
